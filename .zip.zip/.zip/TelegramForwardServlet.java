import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TelegramForwardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Replace 'YOUR_BOT_TOKEN' with your bot's token
    private static final String BOT_TOKEN = "YOUR_BOT_TOKEN";
    // Replace 'CHANNEL_ID' with your private channel ID
    private static final String CHANNEL_ID = "@YOUR_CHANNEL_NAME";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String message = request.getParameter("message");
        forwardMessageToTelegram(message);
        
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        out.println("Message forwarded to Telegram!");
    }

    private void forwardMessageToTelegram(String message) {
        // Write code here to forward 'message' to Telegram using the Telegram Bot API
        // You can use libraries like OkHttp or HttpClient to make HTTP requests
        // Example:
        // POST https://api.telegram.org/bot<YOUR_BOT_TOKEN>/sendMessage
        // Body: chat_id=<YOUR_CHANNEL_ID>&text=<MESSAGE_TO_FORWARD>
    }
}